-- Task 1  
create schema ZomatoDB;
use ZomatoDB;


-- Task 2
-- 1.	Basic Data Cleaning 
select * from Zomato_Orders;
select * from Zomato_Restaurants;-- where restaurant_id = '08ba20de';

select distinct(customer_id),count(*) as count from Zomato_Orders group by customer_id order by count desc;

select distinct(restaurant_id),count(*) as count from Zomato_Restaurants group by restaurant_id order by count desc;

select r.city,count(o.order_id) as count from Zomato_Orders o join Zomato_Restaurants r on o.restaurant_id = r.restaurant_id 
group by r.city order by count desc;

select r.restaurant_name,round(sum(o.total_cost * o.item_count))as revenue from zomato_orders o join Zomato_Restaurants r 
on o.restaurant_id = r.restaurant_id 
group by r.restaurant_name order by revenue desc;

-- Task2.3
select round(avg(o.total_cost)),r.city from Zomato_Orders o join Zomato_Restaurants r on o.restaurant_id = r.restaurant_id group by r.city;

-- Task2.3.b
select r.restaurant_name,round(sum(o.total_cost * o.item_count))as Total_sales from zomato_orders o join Zomato_Restaurants r
on o.restaurant_id = r.restaurant_id 
group by r.restaurant_name order by Total_sales desc limit 5;

-- Task2.4
select * from Zomato_Restaurants r left JOIN Zomato_Orders o on r.restaurant_id = o.restaurant_id;